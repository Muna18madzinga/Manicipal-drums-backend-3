import os
import json
import requests
from qgis.core import QgsProject, QgsVectorLayer, QgsTask, QgsMessageLog, QgsGeometry
from qgis.PyQt.QtCore import QSettings, QObject, pyqtSignal
from qgis.server import QgsServerInterface

class VunguServerFilter:
    def __init__(self, server_iface):
        self.server_iface = server_iface
        self.api_base = QSettings().value('vungu/api_url', 'http://localhost:3000/api')
        
    def requestReady(self):
        """Handle incoming requests"""
        request = self.server_iface.requestHandler()
        params = request.parameterMap()
        
        # Handle Vungu API endpoints
        if 'SERVICE' in params and params['SERVICE'] == 'VUNGU':
            self.handle_vungu_request(request, params)
            
    def handle_vungu_request(self, request, params):
        """Handle Vungu-specific requests"""
        try:
            endpoint = params.get('REQUEST', '')
            
            if endpoint == 'GetLayers':
                self.get_layers(request)
            elif endpoint == 'SyncStyles':
                self.sync_styles(request)
            elif endpoint == 'ExportData':
                self.export_data(request)
            else:
                request.setStatusCode(400)
                request.sendHeader('Content-type', 'application/json')
                request.write(b'{"error": "Invalid request"}')
                
        except Exception as e:
            QgsMessageLog.logMessage(f"Vungu plugin error: {str(e)}", 'VunguPlugin', Qgis.Critical)
            request.setStatusCode(500)
            request.sendHeader('Content-type', 'application/json')
            request.write(json.dumps({"error": str(e)}).encode())
            
    def get_layers(self, request):
        """Get available layers from Vungu portal"""
        try:
            response = requests.get(f"{self.api_base}/dynamic-layers/layers", timeout=10)
            if response.status_code == 200:
                request.setStatusCode(200)
                request.sendHeader('Content-type', 'application/json')
                request.write(response.content)
            else:
                request.setStatusCode(response.status_code)
                request.sendHeader('Content-type', 'application/json')
                request.write(b'{"error": "Failed to fetch layers"}')
        except Exception as e:
            request.setStatusCode(500)
            request.sendHeader('Content-type', 'application/json')
            request.write(json.dumps({"error": str(e)}).encode())
            
    def sync_styles(self, request):
        """Sync QGIS styles with Vungu portal"""
        # Implementation for style synchronization
        request.setStatusCode(200)
        request.sendHeader('Content-type', 'application/json')
        request.write(b'{"success": true, "message": "Styles synced"}')
        
    def export_data(self, request):
        """Export data to Vungu portal"""
        # Implementation for data export
        request.setStatusCode(200)
        request.sendHeader('Content-type', 'application/json')
        request.write(b'{"success": true, "message": "Data exported"}')

class VunguServer:
    def __init__(self, server_iface):
        self.server_iface = server_iface
        self.filter = VunguServerFilter(server_iface)
        
    def initServer(self):
        """Initialize server plugin"""
        self.server_iface.registerFilter(self.filter, 100)
